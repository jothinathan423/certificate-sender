from PIL import Image, ImageDraw, ImageFont
import pandas as pd
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication

# Function to insert name into the image template
def insert_name_into_image(template_path, name, output_path):
    image = Image.open(template_path)
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default()  # You can customize the font and size

    # Adjust the coordinates based on your template
    x = 100
    y = 200

    # Insert the name into the image
    draw.text((x, y), f"This is to certify that {name} has successfully completed the program.", fill="black", font=font)
    image.save(output_path)

# Function to send email with certificate attachment
def send_certificate_email(recipient_email, name, certificate_path):
    sender_email = 'your_email@gmail.com'
    sender_password = 'your_email_password'

    message = MIMEMultipart()
    message['From'] = sender_email
    message['To'] = recipient_email
    message['Subject'] = 'Certificate of Achievement'

    body = f"Dear {name},\n\nCongratulations on completing the program! Please find your certificate attached.\n\nBest regards,\nYour Name"
    message.attach(MIMEText(body, 'plain'))

    certificate_attachment = MIMEApplication(open(certificate_path, 'rb').read(), _subtype="image/png")  # Adjust the subtype based on your image type
    certificate_attachment.add_header('Content-Disposition', f'attachment; filename=certificate_{name}.png')  # Adjust the filename extension based on your image type
    message.attach(certificate_attachment)

    with smtplib.SMTP('smtp.gmail.com', 587) as server:
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, recipient_email, message.as_string())

# Read data from Excel file
excel_file_path = 'sam.xlsx'
df = pd.read_excel(excel_file_path)

# Iterate through the Excel data and generate/send certificates
for index, row in df.iterrows():
    name = row['Name']
    email = row['Email']

    template_path = 'certificate_template.png'  # Replace with the path to your image template
    output_path = f'certificate_{name}.png'  # Adjust the filename extension based on your image type

    insert_name_into_image(template_path, name, output_path)
    send_certificate_email(email, name, output_path)

print("Certificates sent successfully.")
