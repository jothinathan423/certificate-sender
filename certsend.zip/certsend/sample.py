import pandas as pd
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from PIL import Image, ImageDraw, ImageFont
import io

# Read data from Excel file
excel_file_path = 'sam.xlsx'
df = pd.read_excel(excel_file_path)

# Function to fill form fields in the template
def fill_form(template_path, output_path, name):
    # Load the JPEG template image
    template_image = Image.open(template_path)

    # Convert the image to 'RGB' mode
    template_image = template_image.convert('RGB')

    draw = ImageDraw.Draw(template_image)

    # Set font properties with the desired font size
    font_size = 100  # Change this value to your desired font size
    font = ImageFont.truetype("arial.ttf", font_size)

    # Assuming 'Name' is the form field in your template
    text = "{}".format(name)
    draw.text((1350, 760), text, font=font, fill=(0, 0, 0))  # black color

    # Save the modified image
    template_image.save(output_path)

# Function to send email with certificate attachment
def send_certificate_email(recipient_email, name, certificate_path):
    sender_email = 'jothinathannagarajan@gmail.com'
    sender_password = 'bkzcxiakzgbgsqsp'

    message = MIMEMultipart()
    message['From'] = sender_email
    message['To'] = recipient_email
    message['Subject'] = 'Certificate of Achievement'

    body = f"Dear {name},\n\nCongratulations on completing the program! Please find your certificate attached.\n\nBest regards,\nYour Name"
    message.attach(MIMEText(body, 'plain'))

    with open(certificate_path, 'rb') as certificate_file:
        certificate_attachment = MIMEApplication(certificate_file.read(), _subtype="jpeg")

    certificate_attachment.add_header('Content-Disposition', f'attachment; filename=certificate_{name}.jpeg')
    message.attach(certificate_attachment)

    with smtplib.SMTP('smtp.gmail.com', 587) as server:
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, recipient_email, message.as_string())

# Iterate through the Excel data and generate/send certificates
for index, row in df.iterrows():
    name = row['Name']
    email = row['Email']

    template_path = 'certificate-temp.jpg'
    output_path = f'certificate_{name}.jpeg'

    fill_form(template_path, output_path, name)
    send_certificate_email(email, name, output_path)

print("Certificates sent successfully.")
